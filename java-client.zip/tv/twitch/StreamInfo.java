package tv.twitch;

public class StreamInfo
{
	public int viewers;				/* The current viewer count. */
	public long streamId;			/* The unique id of the stream. */
}
