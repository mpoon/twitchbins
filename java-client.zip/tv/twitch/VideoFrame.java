package tv.twitch;

public class VideoFrame
{
	public byte[] frameBuffer;			/* Raw bytes of the frame - the frame resolution MUST match the resolution of the output video */
	//TTV_BufferUnlockCallback callback;		/* callback that gets called when VideoFrame is no longer needed */
	//protected Object userData;							/* userData passed to the callback */
	public long mTimeStamp;						/* For internal use */
}
