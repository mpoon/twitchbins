package tv.twitch;

public interface IStreamCallbacks
{
    void requestAuthTokenCallback(ErrorCode ret, AuthToken result);
    void loginCallback(ErrorCode ret, ChannelInfo result);
    void getIngestServersCallback(ErrorCode ret, IngestList result);
    void getUserInfoCallback(ErrorCode ret, UserInfo result);
    void getStreamInfoCallback(ErrorCode ret, StreamInfo result);
    void getArchivingStateCallback(ErrorCode ret, ArchivingState result);
    void runCommercialCallback(ErrorCode ret);
    void getGameNameListCallback(ErrorCode ret, GameInfoList result);
    void bufferUnlockCallback(long buffer);
}
