package tv.twitch;

public class StreamInfoForSetting
{
	public String streamTitle;			/* The title of the stream. If the first character is null, this parameter is ignored. */
	public String gameName;				/* The name of the game being played. If the first character is null, this parameter is ignored. */	
}
