package tv.twitch;


public abstract class StreamAPI
{
	public abstract void setStreamCallbacks(IStreamCallbacks callbacks);
	public abstract void setStatCallbacks(IStatCallbacks callbacks);
	
	public abstract ErrorCode requestAuthToken(AuthParams authParams);
	public abstract ErrorCode login(AuthToken authToken);
	public abstract ErrorCode getIngestServers(AuthToken authToken);
	public abstract ErrorCode getUserInfo(AuthToken authToken);
	public abstract ErrorCode getStreamInfo(AuthToken authToken, String channel);
	public abstract ErrorCode setStreamInfo(AuthToken authToken, String channel, StreamInfoForSetting streamInfoToSet);
	public abstract ErrorCode getArchivingState(AuthToken authToken);
	public abstract ErrorCode runCommercial(AuthToken authToken);
	public abstract ErrorCode setVolume(AudioDeviceType device, float volume);
	public abstract float getVolume(AudioDeviceType device);
	public abstract ErrorCode getGameNameList(String str);
	public abstract ErrorCode getDefaultParams(VideoParams vidParams);
	public abstract int[] getMaxResolution(int maxKbps, int frameRate, float bitsPerPixel, float aspectRatio);
	public abstract ErrorCode pollTasks();
	public abstract ErrorCode init(String clientID, String caCertFile, VideoEncoder vidEncoder, String dllPath);
	public abstract ErrorCode shutdown();
	public abstract ErrorCode sendActionMetaData(AuthToken authToken, String type, long interestHintOffset, String humanDescription, String data);
	public abstract long sendStartSpanMetaData(AuthToken authToken, String type, String humanDescription, String data);
	public abstract ErrorCode sendEndSpanMetaData(AuthToken authToken, String type, long sequenceId, String humanDescription, String data);
	public abstract ErrorCode submitVideoFrame(long buffer);
	public abstract ErrorCode setTraceLevel(MessageLevel traceLevel);
	public abstract ErrorCode setTraceOutput(String outputFilePath);
	public abstract ErrorCode start(VideoParams videoParams, AudioParams audioParams, IngestServer ingestServer, int flags);
	public abstract ErrorCode stop();
	public abstract ErrorCode pauseVideo();
	public abstract long allocateFrameBuffer(int size);
	public abstract ErrorCode freeFrameBuffer(long buffer);
	public abstract ErrorCode captureFrameBuffer_ReadPixels(long buffer, boolean slowFlipVertically);
	public abstract String errorToString(ErrorCode err);
}
