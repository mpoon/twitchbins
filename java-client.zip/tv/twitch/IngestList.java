package tv.twitch;


public class IngestList
{
	public IngestServer[] list = null;
}
