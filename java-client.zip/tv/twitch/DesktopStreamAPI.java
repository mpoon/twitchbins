package tv.twitch;

public class DesktopStreamAPI extends StreamAPI
{
	public DesktopStreamAPI()
	{
		System.loadLibrary("twitchsdk");
	}

    protected void finalize()
    {
    	TTV_Java_SetStreamCallbacks(null);
    	TTV_Java_SetStatCallbacks(null);
    }	
	
	private static native void TTV_Java_SetStreamCallbacks(IStreamCallbacks callback);
	private static native void TTV_Java_SetStatCallbacks(IStatCallbacks callback);
	
	private static native ErrorCode TTV_Java_RequestAuthToken(AuthParams authParams);
    private static native ErrorCode TTV_Java_Login(AuthToken authToken);
    private static native ErrorCode TTV_Java_GetIngestServers(AuthToken authToken);
    private static native ErrorCode TTV_Java_GetUserInfo(AuthToken authToken);
    private static native ErrorCode TTV_Java_GetStreamInfo(AuthToken authToken, String channel);
    private static native ErrorCode TTV_Java_SetStreamInfo(AuthToken authToken, String channel, StreamInfoForSetting streamInfoToSet);
    private static native ErrorCode TTV_Java_GetArchivingState(AuthToken authToken);
    private static native ErrorCode TTV_Java_RunCommercial(AuthToken authToken);
    private static native ErrorCode TTV_Java_SetVolume(AudioDeviceType device, float volume);
    private static native float TTV_Java_GetVolume(AudioDeviceType device);
    private static native ErrorCode TTV_Java_GetGameNameList(String str);
    private static native ErrorCode TTV_Java_GetDefaultParams(VideoParams vidParams);
    private static native ErrorCode TTV_GetMaxResolution(int maxKbps, int frameRate, float bitsPerPixel, float aspectRatio, int[] resolution);
    private static native ErrorCode TTV_Java_PollTasks();
	private static native ErrorCode TTV_Java_Init(String clientID, String caCertFile, /*VideoEncoder*/ int vidEncoder, String dllPath);
    private static native ErrorCode TTV_Java_Shutdown();
    private static native ErrorCode TTV_Java_SendActionMetaData(AuthToken authToken, String type, long interestHintOffset, String humanDescription, String data);
    private static native long TTV_Java_SendStartSpanMetaData(AuthToken authToken, String type, String humanDescription, String data);
    private static native ErrorCode TTV_Java_SendEndSpanMetaData(AuthToken authToken, String type, long sequenceId, String humanDescription, String data);
    private static native ErrorCode TTV_Java_SubmitVideoFrame(long buffer);
    private static native ErrorCode TTV_Java_SetTraceLevel(/*MessageLevel*/ int traceLevel);
    private static native ErrorCode TTV_Java_SetTraceOutput(String outputFilePath);
    private static native ErrorCode TTV_Java_Start(VideoParams videoParams, AudioParams audioParams, IngestServer ingestServer, int flags);
    private static native ErrorCode TTV_Java_Stop();
    private static native ErrorCode TTV_Java_PauseVideo();
    private static native long TTV_Java_AllocateFrameBuffer(int size);
    private static native ErrorCode TTV_Java_FreeFrameBuffer(long buffer);
    private static native ErrorCode TTV_Java_CaptureFrameBuffer_ReadPixels(long buffer, boolean slowFlipVertically);
    private static native String TTV_Java_ErrorToString(ErrorCode err);
	
    @Override
	public void setStreamCallbacks(IStreamCallbacks callbacks)
	{
    	TTV_Java_SetStreamCallbacks(callbacks);
	}

    @Override
	public void setStatCallbacks(IStatCallbacks callbacks)
	{
    	TTV_Java_SetStatCallbacks(callbacks);
	}

    @Override
    public ErrorCode requestAuthToken(AuthParams authParams)
    {
    	return TTV_Java_RequestAuthToken(authParams);
    }

    @Override
    public ErrorCode login(AuthToken authToken)
    {
        return TTV_Java_Login(authToken);
    }

    @Override
	public ErrorCode getIngestServers(AuthToken authToken)
    {
    	return TTV_Java_GetIngestServers(authToken);
    }
    
    @Override
	public ErrorCode getUserInfo(AuthToken authToken)
    {
    	return TTV_Java_GetUserInfo(authToken);
    }
    
    @Override
	public ErrorCode getStreamInfo(AuthToken authToken, String channel)
    {
    	return TTV_Java_GetStreamInfo(authToken, channel);
    }
    
    @Override
	public ErrorCode setStreamInfo(AuthToken authToken, String channel, StreamInfoForSetting streamInfoToSet)
    {
    	return TTV_Java_SetStreamInfo(authToken, channel, streamInfoToSet);
    }
    
    @Override
	public ErrorCode getArchivingState(AuthToken authToken)
    {
    	return TTV_Java_GetArchivingState(authToken);
    }
    
    @Override
	public ErrorCode runCommercial(AuthToken authToken)
    {
    	return TTV_Java_RunCommercial(authToken);
    }

    @Override
	public ErrorCode setVolume(AudioDeviceType device, float volume)
	{
    	return TTV_Java_SetVolume(device, volume);
	}
	
    @Override
	public float getVolume(AudioDeviceType device)
	{
    	return TTV_Java_GetVolume(device);
	}
    
    @Override
	public ErrorCode getGameNameList(String str)
    {
    	return TTV_Java_GetGameNameList(str);
    }
    
    @Override
	public ErrorCode getDefaultParams(VideoParams vidParams)
    {
    	return TTV_Java_GetDefaultParams(vidParams);
    }
    
    @Override
    public int[] getMaxResolution(int maxKbps, int frameRate, float bitsPerPixel, float aspectRatio)
    {
    	int[] resolution = new int[]{0,0};
    	TTV_GetMaxResolution(maxKbps, frameRate, bitsPerPixel, aspectRatio, resolution);
    	return resolution;
    }
    
    @Override
    public ErrorCode pollTasks()
    {
    	return TTV_Java_PollTasks();
    }

    @Override
    public ErrorCode init(String clientID, String caCertFile, VideoEncoder vidEncoder, String dllPath)
    {
    	return TTV_Java_Init(clientID, caCertFile, vidEncoder.getValue(), dllPath);
    }

    @Override
    public ErrorCode shutdown()
	{
    	return TTV_Java_Shutdown();
	}

    @Override
	public ErrorCode sendActionMetaData(AuthToken authToken, String type, long interestHintOffset, String humanDescription, String data)
    {
    	return TTV_Java_SendActionMetaData(authToken, type, interestHintOffset, humanDescription, data);
    }
    
    @Override
	public long sendStartSpanMetaData(AuthToken authToken, String type, String humanDescription, String data)
    {
    	return TTV_Java_SendStartSpanMetaData(authToken, type, humanDescription, data);
    }
    
    @Override
	public ErrorCode sendEndSpanMetaData(AuthToken authToken, String type, long sequenceId, String humanDescription, String data)
    {
    	return TTV_Java_SendEndSpanMetaData(authToken, type, sequenceId, humanDescription, data);
    }
    
    @Override
	public ErrorCode submitVideoFrame(long buffer)
    {
    	return TTV_Java_SubmitVideoFrame(buffer);
    }   
        
    @Override
    public ErrorCode setTraceLevel(MessageLevel traceLevel)
    {
    	return TTV_Java_SetTraceLevel(traceLevel.getValue());
    }

    @Override
	public ErrorCode setTraceOutput(String outputFilePath)
    {
    	return TTV_Java_SetTraceOutput(outputFilePath);
    }
    
    @Override
	public ErrorCode start(VideoParams videoParams, AudioParams audioParams, IngestServer ingestServer, int flags)
    {
    	return TTV_Java_Start(videoParams, audioParams, ingestServer, flags);
    }

    @Override
    public ErrorCode stop()
    {
    	return TTV_Java_Stop();
    }

    @Override
    public ErrorCode pauseVideo()
    {
    	return TTV_Java_PauseVideo();
    }

    @Override
	public long allocateFrameBuffer(int size)
    {
    	return TTV_Java_AllocateFrameBuffer(size);
    }

    @Override
	public ErrorCode freeFrameBuffer(long buffer)
    {
    	return TTV_Java_FreeFrameBuffer(buffer);
    }

    @Override
    public ErrorCode captureFrameBuffer_ReadPixels(long buffer, boolean slowFlipVertically)
    {
    	return TTV_Java_CaptureFrameBuffer_ReadPixels(buffer, slowFlipVertically);
    }
    
    @Override
	public String errorToString(ErrorCode err)
    {
    	if (err == null)
    	{
    		return null;
    	}
    	
    	return TTV_Java_ErrorToString(err);
    }
}
