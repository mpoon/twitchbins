package tv.twitch;

import java.util.HashMap;
import java.util.Map;


public class FrameBuffer
{
	private static Map<Long, FrameBuffer> s_OutstandingBuffers = new HashMap<Long, FrameBuffer>();

	public static FrameBuffer lookupBuffer(long address)
	{
		return s_OutstandingBuffers.get(address);
	}

	protected static void registerBuffer(FrameBuffer buffer)
	{
		if (buffer.getAddress() != 0)
		{
			s_OutstandingBuffers.put(buffer.getAddress(), buffer);
		}
	}

	protected static void unregisterBuffer(FrameBuffer buffer)
	{
		s_OutstandingBuffers.remove(buffer.getAddress());
	}
	
	protected long m_NativeAddress = 0;
	protected int m_Size = 0;
	protected StreamAPI m_API = null;
	
	FrameBuffer(StreamAPI api, int size)
	{
		m_NativeAddress = api.allocateFrameBuffer(size);

		if (m_NativeAddress == 0)
		{
			return;
		}

		m_API = api;
		m_Size = size;
		
		registerBuffer(this);
	}
	
	public boolean getIsValid()
	{
		return m_NativeAddress != 0;
	}
	
	public int getSize()
	{
		return m_Size;
	}

	public long getAddress()
	{
		return m_NativeAddress;
	}
	
	public void free()
	{
    	if (m_NativeAddress != 0)
    	{
    		unregisterBuffer(this);
    		
    		m_API.freeFrameBuffer(m_NativeAddress);
    		m_NativeAddress = 0;
    	}
    }
	
    protected void finalize()
    {
    	free();
    }
}
