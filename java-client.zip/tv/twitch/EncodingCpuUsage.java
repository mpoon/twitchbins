package tv.twitch;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum EncodingCpuUsage
{
	TTV_ECU_LOW(0),
	TTV_ECU_MEDIUM(1),
	TTV_ECU_HIGH(2);

	private static Map<Integer, EncodingCpuUsage> s_Map = new HashMap<Integer, EncodingCpuUsage>();

	static
	{
		EnumSet<EncodingCpuUsage> set = EnumSet.allOf(EncodingCpuUsage.class);
		
		for (EncodingCpuUsage e : set)
		{
			s_Map.put(e.getValue(), e);
		}
	}
	
	public static EncodingCpuUsage lookupValue(int val)
	{
		EncodingCpuUsage err = s_Map.get(val);
		return err;
	}
	
    private int m_Value;

    private EncodingCpuUsage(int value)
    {
    	this.m_Value = value;
    }
    
    public int getValue()
    {
    	return m_Value;
    }
}
