package tv.twitch;

public class UserInfo
{
	public String displayName;				/* The displayed name */	
	public String name;						/* The user name */	
}
