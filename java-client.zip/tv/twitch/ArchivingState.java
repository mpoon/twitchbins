package tv.twitch;


public class ArchivingState
{
	public boolean recordingEnabled;		/* Recording is enabled/disabled for the channel */
	public String cureUrl;					/* The URL for where the user can go to enable video recording for the channel */
}
