package tv.twitch;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum AudioEncoder 
{
	TTV_AUD_ENC_DEFAULT(-1),
	TTV_AUD_ENC_LAMEMP3(0),
	TTV_AUD_ENC_APPLEAAC(1);

	private static Map<Integer, AudioEncoder> s_Map = new HashMap<Integer, AudioEncoder>();

	static
	{
		EnumSet<AudioEncoder> set = EnumSet.allOf(AudioEncoder.class);
		
		for (AudioEncoder e : set)
		{
			s_Map.put(e.getValue(), e);
		}
	}
	
	public static AudioEncoder lookupValue(int val)
	{
		AudioEncoder err = s_Map.get(val);
		return err;
	}
	
    private int m_Value;

    private AudioEncoder(int value)
    {
    	this.m_Value = value;
    }
    
    public int getValue()
    {
    	return m_Value;
    }
}
