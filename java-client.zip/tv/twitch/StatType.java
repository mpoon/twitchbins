package tv.twitch;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum StatType
{
	TTV_ST_RTMPSTATE(0),
	TTV_ST_RTMPDATASENT(1);

	private static Map<Integer, StatType> s_Map = new HashMap<Integer, StatType>();

	static
	{
		EnumSet<StatType> set = EnumSet.allOf(StatType.class);
		
		for (StatType e : set)
		{
			s_Map.put(e.getValue(), e);
		}
	}
	
	public static StatType lookupValue(int val)
	{
		StatType err = s_Map.get(val);
		return err;
	}
	
    private int m_Value;

    private StatType(int value)
    {
    	this.m_Value = value;
    }
    
    public int getValue()
    {
    	return m_Value;
    }
}

