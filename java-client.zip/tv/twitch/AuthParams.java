package tv.twitch;


public class AuthParams
{
	public String userName;				/* Twitch user name */
	public String password;				/* Twitch password */	
	public String clientSecret;			/* Twitch client secret */
}
