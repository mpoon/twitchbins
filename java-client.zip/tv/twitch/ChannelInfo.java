package tv.twitch;

public class ChannelInfo
{
	public String displayName;				/* The displayed name */	
	public String name;						/* The user name */
	public String channelUrl; 				/* The URL to that channel */
}
