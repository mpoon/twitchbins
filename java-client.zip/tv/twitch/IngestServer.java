package tv.twitch;


public class IngestServer
{
	public String serverName;			/* The ingest server name */	
	public String serverUrl;				/* The ingest server URL */	
	public boolean defaultServer;		/* Is this the default ingest server to use */
}
