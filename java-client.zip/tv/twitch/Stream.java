package tv.twitch;


public class Stream 
{
	//region Singleton 
	
    static Stream s_Instance = null;

    public static Stream getInstance()
    {
        return s_Instance;
    }
	
    //endregion
    
    
    StreamAPI m_StreamAPI = null;  //!< The implementation of the native API.

    public Stream(StreamAPI api)
    {
        m_StreamAPI = api;

        if (s_Instance == null)
        {
            s_Instance = this;
        }
    }
    
    protected void finalize()
    {
        if (s_Instance == this)
        {
            s_Instance = null;
        }
    }
    
    
	//region Public API 

    public void setStreamCallbacks(IStreamCallbacks callbacks)
    {
    	m_StreamAPI.setStreamCallbacks(callbacks);
    }
    
    public FrameBuffer allocateFrameBuffer(int size)
    {
        return new FrameBuffer(m_StreamAPI, size);
    }

    public ErrorCode requestAuthToken(AuthParams authParams)
    {
        ErrorCode ret = m_StreamAPI.requestAuthToken(authParams);
        return ret;
    }

    public ErrorCode login(AuthToken authToken)
    {
        ErrorCode ret = m_StreamAPI.login(authToken);
        return ret;
    }

    public ErrorCode getIngestServers(AuthToken authToken)
    {
        return m_StreamAPI.getIngestServers(authToken);
    }

    public ErrorCode getUserInfo(AuthToken authToken)
    {
        return m_StreamAPI.getUserInfo(authToken);
    }

    public ErrorCode getStreamInfo(AuthToken authToken, String channel)
    {
        return m_StreamAPI.getStreamInfo(authToken, channel);
    }

    public ErrorCode setStreamInfo(AuthToken authToken, String channel, StreamInfoForSetting info)
    {
        return m_StreamAPI.setStreamInfo(authToken, channel, info);
    }

    public ErrorCode getArchivingState(AuthToken authToken)
    {
        return m_StreamAPI.getArchivingState(authToken);
    }

    public ErrorCode runCommercial(AuthToken authToken)
    {
        return m_StreamAPI.runCommercial(authToken);
    }

    public ErrorCode setVolume(AudioDeviceType device, float volume)
    {
        return m_StreamAPI.setVolume(device, volume);
    }

    public float getVolume(AudioDeviceType device)
    {
        return m_StreamAPI.getVolume(device);
    }
    
    public ErrorCode getGameNameList(String str)
    {
        return m_StreamAPI.getGameNameList(str);
    }

    public ErrorCode getDefaultParams(VideoParams vidParams)
    {
        return m_StreamAPI.getDefaultParams(vidParams);
    }

    public int[] getMaxResolution(int maxKbps, int frameRate, float bitsPerPixel, float aspectRatio)
    {
        return m_StreamAPI.getMaxResolution(maxKbps, frameRate, bitsPerPixel, aspectRatio);
    }

    public ErrorCode pollTasks()
    {
        ErrorCode ret = m_StreamAPI.pollTasks();
        return ret;
    }

    public ErrorCode initialize(String clientID, String caCertFile, VideoEncoder vidEncoder, String dllPath)
    {
        ErrorCode ret = m_StreamAPI.init(clientID, caCertFile, vidEncoder, dllPath);
        return ret;
    }

    public ErrorCode shutdown()
    {
        ErrorCode ret = m_StreamAPI.shutdown();
        return ret;
    }

    public ErrorCode sendActionMetaData(AuthToken authToken, String type, long interestHintOffset, String humanDescription, String data)
    {
        ErrorCode ret = m_StreamAPI.sendActionMetaData(authToken, type, interestHintOffset, humanDescription, data);
        return ret;
    }

    public long sendStartSpanMetaData(AuthToken authToken, String type, String humanDescription, String data)
    {
    	long ret = m_StreamAPI.sendStartSpanMetaData(authToken, type, humanDescription, data);
        return ret;
    }

    public ErrorCode sendEndSpanMetaData(AuthToken authToken, String type, long sequenceId, String humanDescription, String data)
    {
        ErrorCode ret = m_StreamAPI.sendEndSpanMetaData(authToken, type, sequenceId, humanDescription, data);
        return ret;
    }

    public ErrorCode submitVideoFrame(FrameBuffer buffer)
    {
        ErrorCode ret = m_StreamAPI.submitVideoFrame(buffer.getAddress());
        return ret;
    }
    
    public ErrorCode captureFrameBuffer_ReadPixels(FrameBuffer buffer, boolean slowFlipVertically)
    {
        ErrorCode ret = m_StreamAPI.captureFrameBuffer_ReadPixels(buffer.getAddress(), slowFlipVertically);
        return ret;
    }
    
    public ErrorCode setTraceLevel(MessageLevel traceLevel)
    {
        ErrorCode ret = m_StreamAPI.setTraceLevel(traceLevel);
        return ret;
    }
    
    public ErrorCode start(VideoParams videoParams, AudioParams audioParams, IngestServer ingestServer, int flags)
    {
        ErrorCode ret = m_StreamAPI.start(videoParams, audioParams, ingestServer, flags);
        return ret;
    }
    
    public ErrorCode stop()
    {
        ErrorCode ret = m_StreamAPI.stop();
        return ret;
    }
    
    public ErrorCode pauseVideo()
    {
        ErrorCode ret = m_StreamAPI.pauseVideo();
        return ret;
    }
    
    public String errorToString(ErrorCode err)
    {
    	String ret = m_StreamAPI.errorToString(err);
        return ret;
    }
}
