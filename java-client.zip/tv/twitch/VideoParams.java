package tv.twitch;

public class VideoParams
{
	public int outputWidth;						/* Width of the output video stream in pixels */
	public int  outputHeight;						/* Height of the output video stream in pixels */
	public PixelFormat pixelFormat;			/* Frame pixel format */
	public int maxKbps;							/* Max bit rate */
	public int targetFps;							/* Target frame rate */
	public EncodingCpuUsage encodingCpuUsage;	/* CPU usage level for video encoding */
}
