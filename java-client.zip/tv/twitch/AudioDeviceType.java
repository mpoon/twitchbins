package tv.twitch;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;


public enum AudioDeviceType
{
	TTV_PLAYBACK_DEVICE(0),
	TTV_RECORDER_DEVICE(1);

	private static Map<Integer, AudioDeviceType> s_Map = new HashMap<Integer, AudioDeviceType>();

	static
	{
		EnumSet<AudioDeviceType> set = EnumSet.allOf(AudioDeviceType.class);
		
		for (AudioDeviceType e : set)
		{
			s_Map.put(e.getValue(), e);
		}
	}
	
	public static AudioDeviceType lookupValue(int val)
	{
		AudioDeviceType err = s_Map.get(val);
		return err;
	}
	
    private int m_Value;

    private AudioDeviceType(int value)
    {
    	this.m_Value = value;
    }
    
    public int getValue()
    {
    	return m_Value;
    }
}
