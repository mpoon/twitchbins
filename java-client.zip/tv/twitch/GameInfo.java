package tv.twitch;


public class GameInfo
{
	public String name; 						/* The display name of the game. */
	public int popularity; 					/* A popularity rating for the game. */
	public int id; 							/* The game's unique id. */
}
