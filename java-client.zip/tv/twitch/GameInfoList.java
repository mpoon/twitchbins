package tv.twitch;


public class GameInfoList
{
	public GameInfo[] list = null;
}
