package tv.twitch;


public class AudioParams
{
	public boolean audioEnabled = true;
}
