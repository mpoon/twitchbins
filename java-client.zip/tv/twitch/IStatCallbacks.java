package tv.twitch;

public interface IStatCallbacks 
{
    void statCallback(StatType type, long data);
}
