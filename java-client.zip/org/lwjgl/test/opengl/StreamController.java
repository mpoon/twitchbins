package org.lwjgl.test.opengl;

import java.util.*;
import tv.twitch.*;


public class StreamController implements IStreamCallbacks, IStatCallbacks
{
    //region Types

    public enum StreamState
    {
        Uninitialized,          //!< InitializeTwitch not called.
        Initialized,            //!< InitializeTwitch has been called.
        Authenticating,         //!< Requesting an AuthToken.
        Authenticated,          //!< Have an AuthToken (not necessarily a valid one).
        LoggingIn,              //!< Waiting to see if the AuthToken is valid).
        LoggedIn,               //!< AuthToken is valid.
        FindingIngestServer,    //!< Determining which server we can stream to.
        FoundIngestServer,      //!< Found the best server to stream to.
        ReadyToStream,          //!< Idle and ready to stream.
        Streaming,              //!< Currently streaming.
        Paused                  //!< Streaming but paused.
    }
	
    public interface Listener
    {
		void onAuthTokenRequestComplete(ErrorCode result, AuthToken authToken);
	    void onLoginAttemptComplete(ErrorCode result);
	    void onGameNameListReceived(ErrorCode result, GameInfo[] list);
	    void onStreamStateChanged(StreamState state);
	    void onLoggedOut();
    }
    
    //endregion


    //region Member Variables

    protected Listener m_Listener = null;
	
    protected String m_ClientId = "";
    protected String m_ClientSecret = "";
    protected String m_CaCertFilePath = "";
    protected String m_DllPath = "";
    protected boolean m_EnableAudio = true;

    protected Stream m_Stream = null;
    protected List<FrameBuffer> m_CaptureBuffers = new ArrayList<FrameBuffer>();
    protected List<FrameBuffer> m_FreeBufferList = new ArrayList<FrameBuffer>();

    protected boolean m_SdkInitialized = false;    //!< Has Stream.Initialize() been called?
    protected boolean m_LoggedIn = false;          //!< The AuthToken as been validated and can be used for calls to the server.

    protected StreamState m_StreamState = StreamState.Uninitialized;

    protected String m_UserName = null;
    protected int m_BroadcastWidth = 640;
    protected int m_BroadcastHeight = 480;
    protected int m_BroadcastFramesPerSecond = 30;

    protected IngestList m_IngestList = new IngestList();
    protected IngestServer m_IngestServer = null;
    protected AuthToken m_AuthToken = new AuthToken();
    protected ChannelInfo m_ChannelInfo = new ChannelInfo();
    protected UserInfo m_UserInfo = new UserInfo();
    protected StreamInfo m_StreamInfo = new StreamInfo();
    protected ArchivingState m_ArchivingState = new ArchivingState();

    //endregion


    //region IStreamCallbacks
    
    public void requestAuthTokenCallback(ErrorCode result, AuthToken authToken)
    {
        if (ErrorCode.succeeded(result))
        {
            // Now that the user is authorized the information can be requested about which server to stream to
            m_AuthToken = authToken;
            setStreamState(StreamState.Authenticated);
        }
        else
        {
            m_AuthToken.data = "";
            setStreamState(StreamState.Initialized);

            String err = ErrorCode.getString(result);
            Util.reportError(String.format("RequestAuthTokenDoneCallback got failure: %s", err));
        }
		
        try
        {
            if (m_Listener != null)
            {
            	m_Listener.onAuthTokenRequestComplete(result, authToken);
            }
        }
        catch (Exception x)
        {
            Util.reportError(x.toString());
        }
    }

    public void loginCallback(ErrorCode result, ChannelInfo channelInfo)
    {
        if (ErrorCode.succeeded(result))
        {
            m_ChannelInfo = channelInfo;
            setStreamState(StreamState.LoggedIn);
            m_LoggedIn = true;
        }
        else
        {
            setStreamState(StreamState.Initialized);
            m_LoggedIn = false;

            String err = ErrorCode.getString(result);
            Util.reportError(String.format("LoginCallback got failure: %s", err));
        }
		
        try
        {
            if (m_Listener != null)
            {
            	m_Listener.onLoginAttemptComplete(result);
            }
        }
        catch (Exception x)
        {
            Util.reportError(x.toString());
        }
    }

    public void getIngestServersCallback(ErrorCode result, IngestList ingestList)
    {
        if (ErrorCode.succeeded(result))
        {
            m_IngestList = ingestList;

            // Find the ingest server to use
            int serverIndex = 0;
            for (int i = 0; i < ingestList.list.length; ++i)
            {
                // Use the default server for now
                if (ingestList.list[i].defaultServer)
                {
                    serverIndex = i;
                    break;
                }
            }

            m_IngestServer = m_IngestList.list[serverIndex];
            setStreamState(StreamState.FoundIngestServer);
        }
        else
        {
            String err = ErrorCode.getString(result);
            Util.reportError(String.format("IngestListCallback got failure: %s", err));
        }
    }

    public void getUserInfoCallback(ErrorCode result, UserInfo userInfo)
    {
        m_UserInfo = userInfo;

        if (ErrorCode.failed(result))
        {
            String err = ErrorCode.getString(result);
            Util.reportError(String.format("UserInfoDoneCallback got failure: %s", err));
        }
    }

    public void getStreamInfoCallback(ErrorCode result, StreamInfo streamInfo)
    {
        m_StreamInfo = streamInfo;

        if (ErrorCode.failed(result))
        {
            //String err = ErrorCode.getString(result);
            //Util.ReportWarning(String.Format("StreamInfoDoneCallback got failure: {0}", err));
        }
    }

    public void getArchivingStateCallback(ErrorCode result, ArchivingState state)
    {
        m_ArchivingState = state;

        if (ErrorCode.failed(result))
        {
            //String err = ErrorCode.getString(result);
            //Util.ReportWarning(String.Format("ArchivingStateDoneCallback got failure: {0}", err));
        }
    }
    
    public void runCommercialCallback(ErrorCode result)
    {
        if (ErrorCode.failed(result))
        {
            String err = ErrorCode.getString(result);
            Util.reportWarning(String.format("RunCommercialCallback got failure: %s", err));
        }
    }

    public void getGameNameListCallback(ErrorCode result, GameInfoList list)
    {
        if (ErrorCode.failed(result))
        {
            String err = ErrorCode.getString(result);
            Util.reportError(String.format("GameNameListCallback got failure: %s", err));
        } 
        
        try
        {
            if (m_Listener != null)
            {
            	m_Listener.onGameNameListReceived(result, list == null ? new GameInfo[0] : list.list);
            }
        }
        catch (Exception x)
        {
            Util.reportError(x.toString());
        }
    }

    public void bufferUnlockCallback(long address)
    {
    	FrameBuffer buffer = FrameBuffer.lookupBuffer(address);
    	
        // Put back on the free list
        m_FreeBufferList.add(buffer);
    }

    //endregion

    
    //region IStatCallbacks
    
    public void statCallback(StatType type, long data)
    {
    	System.out.println();
    }
    
    //endregion

    //region Properties

    public boolean getIsInitialized()
    {
        return m_SdkInitialized;
    }

    public String getClientId()
    {
        return m_ClientId;
    }
    public void setClientId(String value)
    {
     	m_ClientId = value;
    }

    public String getClientSecret()
    {
        return m_ClientSecret;
    }
    public void setClientSecret(String value)
    {
        m_ClientSecret = value;
    }

    public String getUserName()
    {
        return m_UserName;
    }
    public void setUserName(String value)
    {
        m_UserName = value;
    }

    public String getCaCertFilePath()
    {
        return m_CaCertFilePath;
    }
    public void setCaCertFilePath(String value)
    {
        m_CaCertFilePath = value;
    }

    public boolean getEnableAudio()
    {
        return m_EnableAudio;
    }
    public void setEnableAudio(boolean value)
    {
        m_EnableAudio = value;
    }

    public StreamState getCurrentState()
    {
        return m_StreamState;
    }

    public ArchivingState getArchivingState()
    {
        return m_ArchivingState;
    }

    public AuthToken getAuthToken()
    {
        return m_AuthToken;
    }

    public StreamInfo getStreamInfo()
    {
        return m_StreamInfo;
    }

    public UserInfo getUserInfo()
    {
        return m_UserInfo;
    }

    public ChannelInfo getChannelInfo()
    {
        return m_ChannelInfo;
    }

    public boolean getIsStreaming()
    {
        return m_StreamState == StreamState.Streaming || m_StreamState == StreamState.Paused;
    }

    public boolean getIsReadyToStream()
    {
        return m_StreamState == StreamState.ReadyToStream;
    }

    public boolean getIsPaused()
    {
        return m_StreamState == StreamState.Paused;
    }

    public boolean getIsLoggedIn()
    {
        return m_LoggedIn;
    }

    public boolean getHaveAuthToken()
    {
        return m_AuthToken != null && m_AuthToken.getIsValid();
    }

    public boolean getHaveIngestServer()
    {
        return m_IngestServer != null;
    }

    public int getBroadcastWidth()
    {
        return m_BroadcastWidth;
    }

    public int getBroadcastHeight()
    {
        return m_BroadcastHeight;
    }

    public Listener getListener()
    {
    	return m_Listener;
    }
    public void setListener(Listener listener)
    {
    	m_Listener = listener;
    }
    
    protected String getDefaultCaCertFilePath()
    {
        return "./curl-ca-bundle.crt";
    }
    
    //endregion

    public StreamController()
    {
    	m_Stream = new Stream(new DesktopStreamAPI());
    }
    
    protected PixelFormat determinePixelFormat()
    {
        return PixelFormat.TTV_PF_RGBA;
    }
    
    public void initializeTwitch()
    {
		if (m_SdkInitialized)
		{
			return;
		}

        String dllPath = m_DllPath;
        if (dllPath == "")
        {
            dllPath = "./";
        }

        String caCertPath = m_CaCertFilePath;
        if (caCertPath == "")
        {
            caCertPath = this.getDefaultCaCertFilePath();
        }

        m_Stream.setStreamCallbacks(this);
        
        ErrorCode err = m_Stream.initialize(m_ClientId, caCertPath, VideoEncoder.TTV_VID_ENC_DEFAULT, dllPath);
        Util.checkError(err);
		
        err = m_Stream.setTraceLevel(MessageLevel.TTV_ML_ERROR);
        Util.checkError(err);

        if (ErrorCode.succeeded(err))
        {
            m_SdkInitialized = true;
            setStreamState(StreamState.Initialized);
        }
    }

    public void shutdownTwitch()
    {
		if (!m_SdkInitialized)
		{
			return;
		}
		
        logout();

        ErrorCode err = m_Stream.shutdown();
        Util.checkError(err);

        m_SdkInitialized = false;
		setStreamState(StreamState.Uninitialized);
    }

    public void requestAuthToken(String username, String password)
    {
        if (!m_SdkInitialized)
        {
            return;
        }

        logout();

        m_UserName = username;

        AuthParams authParams = new AuthParams();
        authParams.userName = username;
        authParams.password = password;
        authParams.clientSecret = m_ClientSecret;

        ErrorCode err = m_Stream.requestAuthToken(authParams);
        Util.checkError(err);

        if (ErrorCode.succeeded(err))
        {
            setStreamState(StreamState.Authenticating);
        }
    }
	
	public void setAuthToken(String username, AuthToken token)
	{
        logout();

        m_UserName = username;
		m_AuthToken = token;
		
		if (this.getIsInitialized())
		{
			setStreamState(StreamState.Authenticated);
		}
	}
	
    public void logout()
    {
        stopStreaming();

        m_UserName = "";
        m_AuthToken = new AuthToken();

        if (!m_LoggedIn)
        {
            return;
        }

        m_LoggedIn = false;

        try
        {
            if (m_Listener != null)
            {
            	m_Listener.onLoggedOut();
            }
        }
        catch (Exception x)
        {
            Util.reportError(x.toString());
        }
    }

    public void setStreamInfo(String channel, String game, String title)
    {
        if (!m_LoggedIn)
        {
            return;
        }

        StreamInfoForSetting info = new StreamInfoForSetting();
        info.streamTitle = title;
        info.gameName = game;

        ErrorCode err = m_Stream.setStreamInfo(m_AuthToken, channel, info);
        Util.checkError(err);
    }

    public void runCommercial()
    {
        if (!this.getIsStreaming())
        {
            return;
        }

        ErrorCode err = m_Stream.runCommercial(m_AuthToken);
        Util.checkError(err);
    }

    /**
     * Determines the recommended streaming parameters based on the maximum bandwidth of the user's internet connection.
     * This is the recommended method if the broadcast resolution can be independent of the game window resolution and 
     * will produce the best visual quality.  The game must submit buffers at the resolution returned in the VideoParams.
     * 
     * @param maxKbps Maximum bitrate supported (this should be determined by running the ingest tester for a given ingest server).
     * @param frameRate The desired frame rate. For a given bitrate and motion factor, a higher framerate will mean a lower resolution.
     * @param bitsPerPixel The bits per pixel used in the final encoded video. A fast motion game (e.g. first person
							shooter) required more bits per pixel of encoded video avoid compression artifacting. Use 0.1 for an 
							average motion game. For games without too many fast changes in the scene, you could use a value below
							0.1 but not much. For fast moving games with lots of scene changes a value as high as  0.2 would be appropriate.
     * @param aspectRatio - The aspect ratio of the video which we'll use for calculating width and height.
     * @return The filled in VideoParams.
     */
    public VideoParams getRecommendedVideoParams(int maxKbps, int frameRate, float bitsPerPixel, float aspectRatio)
    {
    	int[] resolution = m_Stream.getMaxResolution(maxKbps, frameRate, bitsPerPixel, aspectRatio);
    	
    	VideoParams videoParams = new VideoParams();
    	videoParams.maxKbps = maxKbps;
    	videoParams.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_HIGH;
    	videoParams.outputWidth = resolution[0];
    	videoParams.outputHeight = resolution[1];
    	videoParams.pixelFormat = determinePixelFormat();
    	videoParams.targetFps = frameRate;

    	return videoParams;
    }
    
    /**
     * Determines the recommended streaming parameters based on the given broadcast resolution.  This method is not recommended unless
     * the game cannot broadcast at a resolution independent of the game window resolution.
     */
    public VideoParams getRecommendedVideoParams(int width, int height, int frameRate)
    {
        VideoParams videoParams = new VideoParams();
        
        videoParams.outputWidth = width;
        videoParams.outputHeight = height;
        videoParams.targetFps = frameRate;
        videoParams.pixelFormat = determinePixelFormat();
        videoParams.encodingCpuUsage = EncodingCpuUsage.TTV_ECU_HIGH;

        // Compute the rest of the fields based on the given parameters
        ErrorCode ret = m_Stream.getDefaultParams(videoParams);
        if (ErrorCode.failed(ret))
        {
            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error in GetDefaultParams: %s", err));
            return null;
        }
        
    	return videoParams;
    }
    
    public boolean startStreaming(VideoParams videoParams)
    {
        if (!this.getIsLoggedIn() || this.getIsStreaming())
        {
            return false;
        }

        ErrorCode ret = ErrorCode.TTV_EC_SUCCESS;

        switch (m_StreamState)
        {
            // SDK not initialized
            case Uninitialized:
                return false;

            // Already trying to stream
            case Initialized:
            case Authenticating:
            case Authenticated:
            case FindingIngestServer:
            case FoundIngestServer:
            case Streaming:
            case Paused:
                return false;

            // Ready to stream
            case ReadyToStream:
                break;
                
            default:
            	return false;
        }
		
		// Validate parameters
        if (videoParams.outputWidth <= 0 || videoParams.outputWidth % 16 != 0 ||
        	videoParams.outputHeight <= 0 || videoParams.outputHeight % 16 != 0)
        {
            Util.reportError("Invalid broadcast size");
            return false;
        }
		
		if (!allocateBuffers(videoParams.outputWidth, videoParams.outputHeight))
		{
			return false;
		}

		// Setup the audio parameters
        AudioParams audioParams = new AudioParams();
        audioParams.audioEnabled = m_EnableAudio;

        ret = m_Stream.start(videoParams, audioParams, m_IngestServer, 0);
        if (ErrorCode.failed(ret))
        {
            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error while starting to stream: %s", err));
            cleanupBuffers();
			return false;
        }

		// Now streaming
        setStreamState(StreamState.Streaming);

        return true;
    }

    public void stopStreaming()
    {
        if (!this.getIsStreaming())
        {
            return;
        }

        // No longer streaming
        setStreamState(StreamState.ReadyToStream);

        ErrorCode ret = m_Stream.stop();
        if (ErrorCode.failed(ret))
        {
            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error while stopping the stream: %s", err));
        }

		cleanupBuffers();
    }
	
	public void pauseStreaming()
	{
	    if (!this.getIsStreaming())
	    {
		    return;
	    }

        ErrorCode ret = m_Stream.pauseVideo();
	    if ( ErrorCode.failed(ret) )
	    {
		    // not streaming anymore
		    stopStreaming();

		    String err = ErrorCode.getString(ret);
		    Util.reportError(String.format("Error pausing stream: %s\n", err));
	    }
		
		setStreamState(StreamState.Paused);
	}
	
	public void resumeStreaming()
	{
	    if (!this.getIsPaused())
	    {
		    return;
	    }
		
		setStreamState(StreamState.Streaming);
	}

    public void sendActionMetaData(String type, long interestHintOffset, String humanDescription, String data)
    {
        ErrorCode ret = m_Stream.sendActionMetaData(m_AuthToken, type, interestHintOffset, humanDescription, data);
        if (ErrorCode.failed(ret))
        {
            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error while sending meta data: %s\n", err));
        }
    }

    public long startSpanMetaData(String type, String humanDescription, String data)
    {
    	long ret = m_Stream.sendStartSpanMetaData(m_AuthToken, type, humanDescription, data);
        if (ret == -1)
        {
            Util.reportError(String.format("Error in SendStartSpanMetaData\n"));
        }
        return ret;
    }

    public void endSpanMetaData(String type, long sequenceId, String humanDescription, String data)
    {
        ErrorCode ret = m_Stream.sendEndSpanMetaData(m_AuthToken, type, sequenceId, humanDescription, data);
        if (ErrorCode.failed(ret))
        {
            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error in SendStopSpanMetaData: %s\n", err));
        }
    }

    public void requestGameNameList(String str)
    {
        ErrorCode ret = m_Stream.getGameNameList(str);
        if (ErrorCode.failed(ret))
        {
            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error in GetGameNameList: %s\n", err));
        }
    }

    protected void setStreamState(StreamState state)
    {
        if (state == m_StreamState)
        {
            return;
        }

        m_StreamState = state;

        System.out.println(state.toString());
        
        try
        {
            if (m_Listener != null)
            {
            	m_Listener.onStreamStateChanged(state);
            }
        }
        catch (Exception x)
        {
            Util.reportError(x.toString());
        }
    }

    public void update()
    {
        ErrorCode ret = m_Stream.pollTasks();
        if (ErrorCode.failed(ret) && ret != ErrorCode.TTV_EC_NOT_INITIALIZED)
        {
            Util.checkError(ret);
        }

	    switch (m_StreamState)
	    {
		    // Kick off an authentication request
		    case Authenticated:
		    {
			    setStreamState(StreamState.LoggingIn);

                ret = m_Stream.login(m_AuthToken);
			    if (ErrorCode.failed(ret))
			    {
				    String err = ErrorCode.getString(ret);
				    Util.reportError(String.format("Error in TTV_Login: %s\n", err));
			    }
			    break;
		    }
		    // Login
		    case LoggedIn:
		    {
			    setStreamState(StreamState.FindingIngestServer);

                ret = m_Stream.getIngestServers(m_AuthToken);
                if (ErrorCode.failed(ret))
			    {
                    setStreamState(StreamState.LoggedIn);

				    String err = ErrorCode.getString(ret);
                    Util.reportError(String.format("Error in TTV_GetIngestServers: %s\n", err));
			    }
			    break;
		    }
		    // Ready to stream
		    case FoundIngestServer:
		    {
			    setStreamState(StreamState.ReadyToStream);

                // Kick off requests for the user and stream information that aren't 100% essential to be ready before streaming starts
                ret = m_Stream.getUserInfo(m_AuthToken);
                if (ErrorCode.failed(ret))
                {
                    String err = ErrorCode.getString(ret);
                    Util.reportError(String.format("Error in TTV_GetUserInfo: %s\n", err));
                }

                ret = m_Stream.getStreamInfo(m_AuthToken, m_UserName);
                if (ErrorCode.failed(ret))
                {
                    String err = ErrorCode.getString(ret);
                    Util.reportError(String.format("Error in TTV_GetStreamInfo: %s\n", err));
                }

                ret = m_Stream.getArchivingState(m_AuthToken);
                if (ErrorCode.failed(ret))
                {
                    String err = ErrorCode.getString(ret);
                    Util.reportError(String.format("Error in TTV_GetArchivingState: %s\n", err));
                }

			    break;
		    }
		    // No action required
		    case FindingIngestServer:
		    case Authenticating:
		    case Initialized:
		    case Uninitialized:		
		    case Paused:
		    {
			    break;
		    }
		    case Streaming:
			{
				break;
			}
		    default:
		    {
			    break;
		    }
	    }
    }
    
    protected boolean allocateBuffers(int width, int height)
    {
        // Allocate exactly 3 buffers to use as the capture destination while streaming.
        // These buffers are passed to the SDK.
        for (int i = 0; i < 3; ++i)
        {
        	FrameBuffer buffer = m_Stream.allocateFrameBuffer(width * height * 4);
            if (!buffer.getIsValid())
            {
                Util.reportError(String.format("Error while allocating frame buffer"));
                return false;
            }

            m_CaptureBuffers.add(buffer);
            m_FreeBufferList.add(buffer);
        }

        return true;
    }
    
    protected void cleanupBuffers()
    {
        // Delete the capture buffers
        for (int i = 0; i < m_CaptureBuffers.size(); ++i)
        {
        	FrameBuffer buffer = m_CaptureBuffers.get(i);
            buffer.free();
        }

        m_FreeBufferList.clear();
        m_CaptureBuffers.clear();
    }

    public FrameBuffer getNextFreeBuffer()
    {
        if (m_FreeBufferList.size() == 0)
        {
            Util.reportError(String.format("Out of free buffers, this should never happen"));
            return null;
        }

        FrameBuffer buffer = m_FreeBufferList.get(m_FreeBufferList.size() - 1);
        m_FreeBufferList.remove(m_FreeBufferList.size() - 1);

        return buffer;
    }
    
    public void captureFrameBuffer_ReadPixels(FrameBuffer buffer, boolean slowFlipVertically)
    {
    	m_Stream.captureFrameBuffer_ReadPixels(buffer, slowFlipVertically);
    }
    
    public void submitFrame(FrameBuffer bgraFrame)
    {
        if (this.getIsPaused())
        {
            resumeStreaming();
        }
        else if (!this.getIsStreaming())
        {
            return;
        }

        ErrorCode ret = m_Stream.submitVideoFrame(bgraFrame);
        if (ErrorCode.failed(ret))
        {
            // not streaming anymore
            stopStreaming();

            String err = ErrorCode.getString(ret);
            Util.reportError(String.format("Error while submitting frame to stream: %s\n", err));
        }
    }
}
