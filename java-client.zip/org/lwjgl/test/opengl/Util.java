package org.lwjgl.test.opengl;

import tv.twitch.*;


public class Util
{
    public static void checkError(ErrorCode err)
    {
        if (err != ErrorCode.TTV_EC_SUCCESS)
        {
        	System.out.println(err.toString());
        }
    }

    public static void reportError(String err)
    {
    	System.out.println(err.toString());
    }

    public static void reportWarning(String err)
    {
    	System.out.println(err.toString());
    }
}
