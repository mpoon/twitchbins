/********************************************************************************************
* Twitch Broadcasting SDK
*
* This software is supplied under the terms of a license agreement with Justin.tv Inc. and
* may not be copied or used except in accordance with the terms of that agreement
* Copyright (c) 2012 Justin.tv Inc.
*********************************************************************************************/

#ifndef TTVSDK_TWITCH_CHAT_H
#define TTVSDK_TWITCH_CHAT_H

#include "twitchsdktypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * TTV_ChatEvent - The various events coming from the chat system.
 */
typedef enum
{
	TTV_CHAT_JOINED_CHANNEL,			//!< Local user joined a channel.
	TTV_CHAT_LEFT_CHANNEL				//!< Local user left a channel.

} TTV_ChatEvent;


/**
 * TTV_ChatUserMode - The various events coming from the chat system.
 */
typedef enum
{
	TTV_CHAT_USERMODE_VIEWER,			//!< A regular viewer.
	TTV_CHAT_USERMODE_BROADCASTER,		//!< The broadcaster.
	TTV_CHAT_USERMODE_MODERATOR,		//!< A moderator.
	TTV_CHAT_USERMODE_STAFF				//!< A member of Twitch.

} TTV_ChatUserMode;


/**
 * This is the maximum length of the user name in bytes, NOT characters.  Be careful with multi-byte characters in UTF-8.  
 * However, user names are currently restricted to ASCII which is confined to the lower 7 bits so the encodings are the same.
 */
#define kMaxChatUserNameLength 255
/**
 * TTV_ChatUserInfo - The user information.
 */
typedef struct
{	
	utf8char displayName[kMaxChatUserNameLength+1];		//!< The UTF-8 encoded displayed name.  Currently restricted to the ASCII subset.
	TTV_ChatUserMode mode;								//!< The mode which controls priviledges in a particular chat room.

} TTV_ChatUserInfo;


/**
 * TTV_ChatUserList - A list of chat users.
 */
typedef struct
{
	TTV_ChatUserInfo* userList;		//!< The array of user info entries.
	unsigned int userCount;			//!< The number of entries in the array.

} TTV_ChatUserList;


/**
 * This is the maximum length of the channel name in bytes, NOT characters.  Be careful with multi-byte characters in UTF-8.  
 * However, user names are currently restricted to ASCII which is confined to the lower 7 bits so the encodings happen to be the same (for now).
 */
#define kMaxChatChannelNameLength 255
/**
 * TTV_ChatChannelInfo - Information about a chat channel.
 */
typedef struct
{
	utf8char name[kMaxChatChannelNameLength+1];			//!< The UTF-8 encoded name of the channel.  Currently restricted to the ASCII subset.
	TTV_ChatUserInfo broadcasterUserInfo;				//!< Information about the broadcaster of the stream.

} TTV_ChatChannelInfo;


/**
 * This is the maximum length of the message in bytes, NOT characters.  Be careful with multi-byte characters in UTF-8.
 */
#define kMaxChatMessageLength 510
/**
 * TTV_ChatMessage - A message from a user in a chat channel.
 */
typedef struct
{
	utf8char userName[kMaxChatUserNameLength+1];		//!< The UTF-8 encoded user that sent the message.  Currently restricted to the ASCII subset.
	utf8char message[kMaxChatMessageLength+1];			//!< The UTF-8 encoded message text.

} TTV_ChatMessage;


/**
 * TTV_ChatMessageList - A list of chat messages.
 */
typedef struct
{
	TTV_ChatMessage* messageList;					//!< The ordered array of chat messages.
	unsigned int messageCount;						//!< The number of messages in the list.

} TTV_ChatMessageList;



/**
 * Callback signature for connection and disconnection events from the chat service.  Once a connecion is successful, this may be
 * called at any time to indicate a disconnect from the server.  If a disconnection occurs, TTV_ChatConnect must be called again
 * to connect to the server and all channels must be rejoined.
 *
 * When a connection is attempted via TTV_ChatConnect, a successful connection will result in the callback being called with TTV_EC_SUCCESS.
 * Otherwise, an error will be returned which can be one of TTV_EC_CHAT_INVALID_LOGIN, TTV_EC_CHAT_LOST_CONNECTION, TTV_EC_CHAT_COULD_NOT_CONNECT.
 */
typedef void (*TTV_ChatStatusCallback) (TTV_ErrorCode result);

/**
 * Callback signature for result of the local user joining or leaving channels.
 *
 * Expected evt values are TTV_CHAT_JOINED_CHANNEL, TTV_CHAT_LEFT_CHANNEL.
 */
typedef void (*TTV_ChatChannelMembershipCallback) (TTV_ChatEvent evt, const TTV_ChatChannelInfo* channelInfo);

/**
 * Callback signature for notifications of users joining or leaving a chat channel.  The lists returned in this callback must be freed by calling TTV_Chat_FreeUserList on each one
 * when the application is done with them.
 */
typedef void (*TTV_ChatChannelUserChangeCallback) (const TTV_ChatUserList* joinList, const TTV_ChatUserList* leaveList);

/**
 * Callback signature for a reply to TTV_ChatGetChannelUsers for a request for the user list for a chat channel.  The list returned in the callback must be freed by 
 * calling TTV_Chat_FreeUserList when the application is done with it or it will leak each time the callback is called.
 */
typedef void (*TTV_ChatQueryChannelUsersCallback) (const TTV_ChatUserList* userList);

/**
 * Callback signature for notifications of a message event occurring in chat.  This list is freed automatically when the call to the callback returns
 * so be sure not to retain a reference to the list.
 */
typedef void (*TTV_ChatChannelMessageCallback) (const TTV_ChatMessageList* messageList);


/**
 * TTV_ChatCallbacks - The set of callbacks to call for notifications from the chat subsystem.
 */
typedef struct
{
	TTV_ChatStatusCallback				statusCallback;			//!< The callback to call for connection and disconnection events from the chat service. Cannot be NULL.
	TTV_ChatChannelMembershipCallback	membershipCallback;		//!< The callback to call when the local user joins or leaves a channel. Cannot be NULL.
	TTV_ChatChannelUserChangeCallback	userCallback;			//!< The callback to call when other users join or leave a channel. This may be NULL.
	TTV_ChatChannelMessageCallback		messageCallback;		//!< The callback to call when a message is received on a channel. Cannot be NULL.

} TTV_ChatCallbacks;


/**
 * TTV_ChatInit - Sets the callbacks for receiving chat events.  This may be NULL to stop receiving chat events but this is not recommended
 *                since you may miss connection and disconnection events.
 *
 * @param[in] channelName - The UTF-8 encoded name of the channel to connect to. See #kMaxChatChannelNameLength for details.
 * @param[in] chatCallbacks - The set of callbacks for receiving chat events.
 * @return - TTV_EC_SUCCESS.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_Init(const utf8char* channelName, const TTV_ChatCallbacks* chatCallbacks);

/**
 * TTV_Chat_Shutdown - Tear down the chat subsystem. Be sure to have freed all outstanding lists before calling this.
 *
 * @return - TTV_EC_SUCCESS.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_Shutdown();

/**
 * TTV_ChatConnect - Connects to the chat service.  This is an asynchronous call and notification of 
 *					 connection success or fail will come in the callback.   TTV_Chat_Init should be called first with 
 *                   valid callbacks for receiving connection and disconnection events.  The actual result of the connection attempt will
 *					 come in the statusCallback.
 *
 * @param[in] username - The UTF-8 encoded account username to use for logging in to chat.  See #kMaxChatUserNameLength for details.
 * @param[in] authToken - The auth token for the account.
 * @return - TTV_EC_SUCCESS if the request to connect is valid (does not guarantee connection, wait for a response from statusCallback).
 *			 TTV_EC_CHAT_NOT_INITIALIZED if system not initialized.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_Connect(const utf8char* username, const TTV_AuthToken* authToken);

/**
 * TTV_ChatDisconnect - Disconnects from the chat server.  This will automatically remove the user from
 *						all channels that the user is in.  A notification will come in statusCallback to indicate
 *						that the disconnection was successful but you can safely assume this will succeed.
 *
 * @return - TTV_EC_SUCCESS if disconnection successful.
 *			 TTV_EC_CHAT_NOT_INITIALIZED if system not initialized.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_Disconnect();

/**
 * TTV_ChatGetChannelUsers - Retrieves the current users for the named channel.  This is used by both broadcasters and viewers.
 *							 The list returned in the callback must be freed by calling TTV_Chat_FreeUserList when the application is done with it.
 *
 * @param[in] callback - The callback to call with the result of the query.
 * @return - TTV_EC_SUCCESS if function succeeds.
 *			 TTV_EC_CHAT_NOT_IN_CHANNEL if not in the channel.
 *			 TTV_EC_CHAT_NOT_INITIALIZED if system not initialized.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_GetChannelUsers(TTV_ChatQueryChannelUsersCallback callback);

/**
 * TTV_Chat_SendMessage - Sends the given message to the channel.  The user must have joined the channel first.  
 *						  This is used by both broadcasters and viewers.
 *
 * @param[in] message - The UTF-8 encoded message to send to the channel.
 * @return - TTV_EC_SUCCESS if function succeeds.
 *			 TTV_EC_CHAT_NOT_INITIALIZED if system not initialized.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_SendMessage(const utf8char* message);

/**
 * TTV_ChatFlushEvents - Calls callbacks for all events which has accumulated since the last flush.  This include connects, disconnects,  
 *						 user changes and received messages.
 *
 * @return - TTV_EC_SUCCESS if function succeeds.
 *			 TTV_EC_CHAT_NOT_INITIALIZED if system not initialized.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_FlushEvents();

/**
 * TTV_Chat_FreeUserList - Frees the memory for the given user list which was passed to the application during a callback.
 *
 * @param[in] userList - The user list to free.
 * @return - TTV_EC_SUCCESS if function succeeds.
 */
TTVSDK_API TTV_ErrorCode TTV_Chat_FreeUserList(const TTV_ChatUserList* userList);


#ifdef __cplusplus
}
#endif

#endif	/* TTVSDK_TWITCH_CHAT_H */
