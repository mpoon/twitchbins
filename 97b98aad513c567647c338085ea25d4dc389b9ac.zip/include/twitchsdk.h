/********************************************************************************************
* Twitch Broadcasting SDK
*
* This software is supplied under the terms of a license agreement with Justin.tv Inc. and
* may not be copied or used except in accordance with the terms of that agreement
* Copyright (c) 2012 Justin.tv Inc.
*********************************************************************************************/

#ifndef TTVSDK_TWITCH_SDK_H
#define TTVSDK_TWITCH_SDK_H

#include "twitchsdktypes.h"

#ifdef __cplusplus
extern "C"
{
#endif


/**
* TTV_Init - Initialize the Twitch Broadcasting SDK
*
* @param[in] memCallbacks - Memory allocation/deallocation callback functions provided by the client. If NULL, malloc/free will be used
* @param[in] clientID - The Twitch client ID assigned to your application
* @param[in] caCertFile - Full path of the CA Cert bundle file (Strongly encourage using the bundle file provided with the SDK)
* @param[in] vidEncoder - The video encoder to use
* @param[in] dllPath - [Optional] Windows Only - Path to DLL's to load if no in exe folder (e.g. Intel DLL) 
* @return - TTV_EC_SUCCESS if function succeeds; error code otherwise
*/
TTVSDK_API TTV_ErrorCode TTV_Init(const TTV_MemCallbacks* memCallbacks, 
								  const char* clientID,
								  const char* caCertFile,
								  TTV_VideoEncoder vidEncoder,
								  const char* dllPath);


#if D3D_SUPPORT_ENABLED
/**
* TTV_InitWithD3D9 - Initialize the Twitch Broadcasting SDK with support for DirectX Video Acceleration
* @param[in] memCallbacks - Memory allocation/deallocation callback functions provided by the client. If NULL, malloc/free will be used
* @param[in] clientID - The Twitch client ID assigned to your application
* @param[in] caCertFile - Full path of the CA Cert bundle file (Strongly encourage using the bundle file provided with the SDK)
* @param[in] d3dDeviceManager - Pointer to the D3D device managare. If this is non-NULL, DirectX Video Acceleration will be used for 
								 color conversion and ecoding operations.
* @param[in] dllPath - [Optional] Windows Only - Path to DLL's to load if no in exe folder (e.g. Intel DLL) 
*/
struct IDirect3DDeviceManager9;
TTVSDK_API TTV_ErrorCode TTV_InitWithD3D9(const TTV_MemCallbacks* memCallbacks,
										  const char* clientID,
										  const char* caCertFile,
										  IDirect3DDeviceManager9* d3dDeviceManager,
										  const char* dllPath);
#endif


/**
* TTV_GetDefaultParams - Fill in the video parameters with default settings based on supplied resolution and target FPS
* @param[in/out] vidParams - The video params to be filled in with default settings
* NOTE: The width, height and targetFps members of the vidParams MUST be set by the caller
* @return - TTV_EC_SUCCESS if function succeeds; error code otherwise
*/
TTVSDK_API TTV_ErrorCode TTV_GetDefaultParams(TTV_VideoParams* vidParams);


/**
* TTV_PollTasks - Polls all currently executing async tasks and if they've finished calls their callbacks
*/
TTVSDK_API TTV_ErrorCode TTV_PollTasks();


/**
* TTV_RequestAuthToken - Request an authentication key based on the provided username and password.
* @param[in] authParams - Authentication parameters
* @param[in] callback - The callback function to be called when the request is completed
* @param[in] userData - Optional pointer to be passed through to the callback function
* @param[out] authToken - The authentication token to be written to
*/					   
TTVSDK_API TTV_ErrorCode TTV_RequestAuthToken(const TTV_AuthParams* authParams,
											  TTV_TaskCallback callback,
											  void* userData,
											  TTV_AuthToken* authToken);


/**
* TTV_GetIngestServers - Get the list of available ingest servers
* @param[in] authToken - The authentication token previously obtained
* @param[in] callback - The callback function to be called when function is completed
* @param[in] userData - Optional pointer to be passed through to the callback function
* @param[out] ingestList - The list of available ingest servers to choose from
*/
TTVSDK_API TTV_ErrorCode TTV_GetIngestServers(const char* authToken,
											  TTV_TaskCallback callback,
											  void* userData,
											  TTV_IngestList* ingestList);


/**
* TTV_FreeIngestList - Must be called after getting the ingest servers to free the allocated list of server info
* @param[in] ingestList - Pointer to the TTV_IngestList struct to be freed
*/
TTVSDK_API TTV_ErrorCode TTV_FreeIngestList(TTV_IngestList* ingestList);


/**
* TTV_PrepareStream - The application must call this and wait for a successful callback before starting to stream
* @param[in] authToken - The authentication token previously obtained
* @param[in] ingestServer - The ingest server to use for streaming (must be one of the servers returned 
							from a previous call to TTV_GetIngestServer)
* @param[in] callback - The callback function to be called when function is completed
* @param[in] userData - Optional pointer to be passed through to the callback function
*/
TTVSDK_API TTV_ErrorCode TTV_PrepareStream(const char* authToken,
										   const TTV_IngestServer* ingestServer,
										   TTV_TaskCallback callback,
										   void* userData);


/**
* TTV_Start - Starts streaming
* @param[in] videoParams - Output stream video paramaters
* @param[in] audioParams - Output stream audio parameters
*/
TTVSDK_API TTV_ErrorCode TTV_Start(const TTV_VideoParams* videoParams,
								   const TTV_AudioParams* audioParams);


/**
* TTV_SubmitVideoFrame - Submit a video frame to be added to the video stream
* @param[in] frameBuffer - Pointer to the frame buffer. This buffer will be considered "locked"
					       until the callback is called.
* @param[in] callback - The callback function to be called when buffer is no longer needed
* @param[in] userData - Optional pointer to be passed through to the callback function
* @return - TTV_EC_SUCCESS if function succeeds; error code otherwise
*/
TTVSDK_API TTV_ErrorCode TTV_SubmitVideoFrame(const uint8_t* frameBuffer, 
											  TTV_BufferUnlockCallback callback,
											  void* userData);


/**
* TTV_SendMetaData - Send some metadata to Twitch
* @param[in] metaData - The metadata to send. This must be in valid JSON format
*/
TTVSDK_API TTV_ErrorCode TTV_SendMetaData(const char* metaData);


/**
* TTV_SetGameInfo - Send game-related information to Twitch
* @param[in] authToken - The authentication token previously obtained
* @param[in] gameInfo - The game-related information to send.
*/
TTVSDK_API TTV_ErrorCode TTV_SetGameInfo(const char* authToken, const TTV_GameInfo* gameInfo);


/**
* TTV_GetUserInfo - Returns user-related information from Twitch
* @param[in] authToken - The authentication token previously obtained
* @param[in] callback - The callback function to be called when user info is retrieved
* @param[in] userData - Optional pointer to be passed through to the callback function
* @param[out] userInfo - The user-related information.
*/
TTVSDK_API TTV_ErrorCode TTV_GetUserInfo(const char* authToken,
                                         TTV_TaskCallback callback,
                                         void* userData,
                                         TTV_UserInfo* userInfo);

/**
* TTV_StreamInfo - Returns stream-related information from Twitch
* @param[in] authToken - The authentication token previously obtained
* @param[in] callback - The callback function to be called when user info is retrieved
* @param[in] userData - Optional pointer to be passed through to the callback function
* @param[out] streamInfo - The stream-related information.
*/
TTVSDK_API TTV_ErrorCode TTV_GetStreamInfo(const char* authToken,
                                           TTV_TaskCallback callback,
                                           void* userData,
                                           const char* channel,
                                           TTV_StreamInfo* streamInfo);


/**
* TTV_GetVolume - Get the volume level for the given device
* @param[in] device - The device to get the volume for
* @param[out] volume - The volume level (0.0 to 1.0)
*/
TTVSDK_API TTV_ErrorCode TTV_GetVolume(TTV_AudioDeviceType device, float* volume);


/**
* TTV_SetVolume - Set the volume level for the given device
* @param[in] device - The device to set the volume for
* @param[in] volume - The volume level (0.0 to 1.0)
*/
TTVSDK_API TTV_ErrorCode TTV_SetVolume(TTV_AudioDeviceType device, float volume);


/**
* TTV_Pause - Pause the video. The SDK will generate frames (e.g. a pause animation)
* util TTV_Unpause is called. Audio will continue to be captured/streamed; you can
* mute audio by setting the volume to <= 0. Submitting a video frame will unpause the stream.
*/
TTVSDK_API TTV_ErrorCode TTV_PauseVideo();


/**
* TTV_Stop - Stops the stream
* @return - TTV_EC_SUCCESS if function succeeds; error code otherwise
*/
TTVSDK_API TTV_ErrorCode TTV_Stop();


/**
* TTV_Shutdown - Shut down the Twitch Broadcasting SDK
* @return - TTV_EC_SUCCESS if function succeeds; error code otherwise
*/
TTVSDK_API TTV_ErrorCode TTV_Shutdown();


/**
* TTV_SetTraceLevel - Sets the minimum threshold for what type of trace messages should be included into the log.
*		For example, if TTV_EC_ERROR is set, only error messages will be added to the log.
*		If TTV_EC_WARNING is set, both warning messages and error messages will be added to the log (since TTV_EC_ERROR passes the minimum threshold set by TTV_EC_WARNING).
* @return - TTV_EC_SUCCESS
*/
TTVSDK_API TTV_ErrorCode TTV_SetTraceLevel(TTV_MessageLevel traceLevel);


/**
* TTV_SetTraceOutput - Sets the file path into which to log tracing.
* @return - TTV_EC_SUCCESS if function succeeds; TTV_EC_CANNOT_OPEN_FILE if the file cannot be opened.
*/
TTVSDK_API TTV_ErrorCode TTV_SetTraceOutput(const char* outputFileName);


#ifdef __cplusplus
}
#endif

#endif	/* TTVSDK_TWITCH_SDK_H */